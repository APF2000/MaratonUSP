cat in/a.in | python3 solution3.py > out/a.out
cat in/b.in | python3 solution3.py > out/b.out
cat in/c.in | python3 solution3.py > out/c.out
cat in/d.in | python3 solution3.py > out/d.out
cat in/e.in | python3 solution3.py > out/e.out
cat in/f.in | python3 solution3.py > out/f.out
cat in/g.in | python3 solution3.py > out/g.out