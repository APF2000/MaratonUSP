// https://codingcompetitions.withgoogle.com/hashcode/round/00000000008f5ca9/00000000008f6f33#inputDataDownloadBox

#include <bits/stdc++.h>

using namespace std;

int main()
{
        return 0;
}
 