cat in/a.in | python3 maximal_independent_set.py > out/a.out
cat in/b.in | python3 maximal_independent_set.py > out/b.out
cat in/c.in | python3 maximal_independent_set.py > out/c.out
cat in/d.in | python3 maximal_independent_set.py > out/d.out
cat in/e.in | python3 maximal_independent_set.py > out/e.out

python3 score.py