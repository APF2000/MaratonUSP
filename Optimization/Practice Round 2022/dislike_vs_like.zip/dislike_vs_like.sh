cat in/a.in | python3 dislike_vs_like.py 0.8 > out/a.out
cat in/b.in | python3 dislike_vs_like.py 0.8 > out/b.out
cat in/c.in | python3 dislike_vs_like.py 0.8 > out/c.out
cat in/d.in | python3 dislike_vs_like.py 0.6 > out/d.out
cat in/e.in | python3 dislike_vs_like.py 0.6 > out/e.out

python3 score.py