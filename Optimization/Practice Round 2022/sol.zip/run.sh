cat in/a.in | python3 solution.py > out/a.out
cat in/b.in | python3 solution.py > out/b.out
cat in/c.in | python3 solution.py > out/c.out
cat in/d.in | python3 solution.py > out/d.out
cat in/e.in | python3 solution.py > out/e.out