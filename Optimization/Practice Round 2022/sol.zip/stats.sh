cat in/a.in | python3 stats.py 0.0 > out/a.out
cat in/b.in | python3 stats.py 0.0 > out/b.out
cat in/c.in | python3 stats.py 0.0 > out/c.out
cat in/d.in | python3 stats.py .0005337318 > out/d.out
cat in/e.in | python3 stats.py .0009028078 > out/e.out

python3 score.py